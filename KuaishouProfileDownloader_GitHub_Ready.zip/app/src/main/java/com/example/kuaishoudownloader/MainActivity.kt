package com.example.kuaishoudownloader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.ConcurrentHashMap

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var logView: TextView
    private lateinit var countView: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var urlEdit: EditText

    private val found = ConcurrentHashMap.newKeySet<String>()
    private var running = false
    private var scrollRounds = 0
    private val maxScrollRounds = 120

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlEdit = findViewById(R.id.profileUrl)
        web = findViewById(R.id.webView)
        logView = findViewById(R.id.logText)
        countView = findViewById(R.id.countText)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.userAgentString =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36"

        web.addJavascriptInterface(JsBridge(), "AndroidDownloader")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (running) {
                    log("Profile page loaded.")
                    scrollRounds = 0
                    scanAndScroll()
                }
            }
        }

        startButton.setOnClickListener { startProfile() }
        stopButton.setOnClickListener { stopProfile() }
    }

    private fun startProfile() {
        val url = urlEdit.text.toString().trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            Toast.makeText(this, "Enter a public Kuaishou profile URL.", Toast.LENGTH_LONG).show()
            return
        }

        found.clear()
        running = true
        scrollRounds = 0
        startButton.isEnabled = false
        stopButton.isEnabled = true
        updateCount()
        log("Opening profile: $url")
        web.loadUrl(url)
    }

    private fun stopProfile() {
        running = false
        stopButton.isEnabled = false
        startButton.isEnabled = true
        log("Stopped. Found ${found.size} video URL(s).")
    }

    private fun scanAndScroll() {
        if (!running) return

        val js = """
            (function(){
              var urls = [];
              document.querySelectorAll('video').forEach(function(v){
                if(v.currentSrc) urls.push(v.currentSrc);
                if(v.src) urls.push(v.src);
              });
              document.querySelectorAll('source').forEach(function(s){
                if(s.src) urls.push(s.src);
              });
              var links = document.querySelectorAll('a[href]');
              links.forEach(function(a){
                var h=a.href||'';
                if(h.indexOf('.mp4')>=0) urls.push(h);
              });
              urls.forEach(function(u){
                try { AndroidDownloader.onMediaUrl(u); } catch(e) {}
              });
              window.scrollTo(0, document.body.scrollHeight);
              return urls.length;
            })();
        """.trimIndent()

        web.evaluateJavascript(js, null)

        scrollRounds++
        if (scrollRounds < maxScrollRounds) {
            web.postDelayed({ scanAndScroll() }, 1800)
        } else {
            log("Auto-scroll finished.")
            stopProfile()
        }
    }

    private fun queueDownload(url: String) {
        if (!running) return
        if (url.startsWith("blob:") || url.startsWith("data:")) return
        if (!url.startsWith("http")) return
        if (!found.add(url)) return

        try {
            val req = DownloadManager.Request(Uri.parse(url))
            req.setTitle("Kuaishou video ${found.size}")
            req.setDescription("Kuaishou Profile Downloader")
            req.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            req.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "Kuaishou/kuaishou_${found.size}.mp4"
            )
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            log("Queued video #${found.size}")
            updateCount()
        } catch (e: Exception) {
            log("Queue error: ${e.message}")
        }
    }

    private fun updateCount() {
        countView.text = "Found: ${found.size}  •  Queued: ${found.size}"
    }

    private fun log(s: String) {
        runOnUiThread {
            logView.append(s + "\n")
        }
    }

    inner class JsBridge {
        @JavascriptInterface
        fun onMediaUrl(url: String) {
            runOnUiThread { queueDownload(url) }
        }
    }

    override fun onDestroy() {
        running = false
        web.stopLoading()
        web.destroy()
        super.onDestroy()
    }
}