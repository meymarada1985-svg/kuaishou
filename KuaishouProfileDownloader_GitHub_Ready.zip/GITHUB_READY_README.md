# Kuaishou Profile Downloader — GitHub Actions APK

This project is prepared so you can upload it to a GitHub repository, run the
**Build Android APK** workflow, and download the generated debug APK.

## Build APK on GitHub

1. Create a new GitHub repository.
2. Upload **all files and folders inside this ZIP** to the repository root.
3. Open the **Actions** tab.
4. Select **Build Android APK**.
5. Click **Run workflow** → **Run workflow**.
6. Wait for the build to finish.
7. Open the completed workflow run.
8. Scroll to **Artifacts**.
9. Download **KuaishouProfileDownloader-debug**.
10. Extract the downloaded artifact ZIP and install `app-debug.apk` on Android.

## Important

- The GitHub workflow explicitly installs Gradle 8.9, which matches the
  Android Gradle Plugin version used by this project.
- The app is intended for public Kuaishou profile URLs.
- It does not bypass private accounts, CAPTCHA, DRM, login restrictions, or
  other access controls.
- Download success depends on whether the public Kuaishou page exposes
  downloadable media URLs to the WebView.

## Local Android Studio build

Open the project in Android Studio and build the `app` module if you prefer
to build locally.
