# Kuaishou Profile Downloader — Android

Android project for downloading publicly exposed Kuaishou video URLs from one public profile.

## App behavior
1. Enter a public Kuaishou profile URL.
2. Press START DOWNLOAD.
3. The app opens the profile in an Android WebView.
4. It scrolls the profile repeatedly.
5. JavaScript checks video/source elements for direct HTTP(S) media URLs.
6. Unique URLs are queued through Android DownloadManager into:
   `Downloads/Kuaishou/`

## Important limitation
Kuaishou is a dynamic website and can use signed URLs, M3U8/HLS, blob URLs, login controls, CAPTCHA, or other delivery mechanisms. This app only queues direct HTTP(S) media URLs exposed to the page. It does not bypass private accounts, DRM, CAPTCHA, or access controls.

## Build the APK

### GitHub Actions (recommended)
1. Create a GitHub repository.
2. Upload this whole project.
3. Open the Actions tab.
4. Run "Build Android APK".
5. Download the artifact named `KuaishouProfileDownloader-debug`.
6. Extract the artifact and install `app-debug.apk` on Android.

### Local build
Requires JDK 17 and Android SDK/Gradle. Run:
`gradle assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

Use only for content you are authorized to download and follow Kuaishou's terms and applicable law.